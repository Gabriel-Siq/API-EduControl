﻿namespace API_EduControl.DTOs.Curso
{
    public class CriarCursoDTO
    {
        public string Nome { get; set; }
        public string Descricao { get; set; } = null!;
    }
}