﻿namespace API_EduControl.DTOs.Matricula
{
    public class CriarMatriculaDTO
    {
        public int AlunoId { get; set; }
        public int CursoId { get; set; }
    }
}
