﻿namespace API_EduControl.DTOs.Curso
{
    public class AtualizarCursoDTO
    {
        public string Nome { get; set; }
        public string Descricao { get; set; } = null!;
    }
}
